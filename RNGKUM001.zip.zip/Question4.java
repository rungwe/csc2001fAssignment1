import java.lang.Math;
public class Question4
{
	public static void main(String[] args)
	{
	int a=5, b=10, c=20, d=15, e=0, f=0, g=0;
	e=Math.max(a,b);
	f=Math.max(c,d);
	g=Math.max(e,f);
	System.out.println(g);
	System.exit(0);
	}
}